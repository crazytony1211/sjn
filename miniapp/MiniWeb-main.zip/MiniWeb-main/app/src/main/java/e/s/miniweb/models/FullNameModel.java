package e.s.miniweb.models;

@SuppressWarnings("unused")
public class FullNameModel {
    public String Name;
    public String Surname;
}
