package com.example.ApiTest;

public class SingleInstanceActivity extends LaunchModeTestActivity {

    public static class SingleInstanceActivity1 extends SingleInstanceActivity {
    }

    public static class SingleInstanceActivity2 extends SingleInstanceActivity {
    }

    public static class SingleInstanceActivity3 extends SingleInstanceActivity {
    }

    public static class SingleInstanceActivity4 extends SingleInstanceActivity {
    }

    public static class SingleInstanceActivity5 extends SingleInstanceActivity {
    }

}
