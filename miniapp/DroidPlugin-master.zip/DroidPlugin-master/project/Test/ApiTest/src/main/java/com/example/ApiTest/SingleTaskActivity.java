package com.example.ApiTest;

public class SingleTaskActivity extends  LaunchModeTestActivity{

    public static class SingleTaskActivity1 extends SingleTaskActivity{}
    public static class SingleTaskActivity2 extends SingleTaskActivity{}
    public static class SingleTaskActivity3 extends SingleTaskActivity{}
    public static class SingleTaskActivity4 extends SingleTaskActivity{}
    public static class SingleTaskActivity5 extends SingleTaskActivity{}

}
