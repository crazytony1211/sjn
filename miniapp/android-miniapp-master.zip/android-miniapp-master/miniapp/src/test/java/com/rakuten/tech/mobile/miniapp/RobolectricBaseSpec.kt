package com.rakuten.tech.mobile.miniapp

import org.junit.Ignore
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
@Ignore("base class")
open class RobolectricBaseSpec
