package com.rakuten.tech.mobile.testapp.ui.settings

interface OnSearchListener {
    fun startSearch(query: String?)
}
