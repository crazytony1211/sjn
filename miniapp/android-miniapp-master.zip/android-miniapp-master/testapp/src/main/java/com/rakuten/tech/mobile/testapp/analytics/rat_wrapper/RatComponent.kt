package com.rakuten.tech.mobile.testapp.analytics.rat_wrapper

interface RatComponent {
    val pageName: String
    val siteSection: String
}
