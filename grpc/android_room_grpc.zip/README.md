# Android Room + gRPC Client (source-only)

This ZIP contains a runnable Android project (source-only) demonstrating:
- Local caching with Room
- gRPC client using OkHttp transport
- Debounce and throttle patterns wired to sync calls

How to run:
1. Open this folder in Android Studio.
2. Gradle will generate protobuf code from `app/src/main/proto/user.proto`.
3. Run on an emulator. Use `10.0.2.2` as host to reach a local gRPC server (e.g., the Spring Boot server on port 9090).

Notes:
- This is intentionally minimal. In production, handle lifecycle, connectivity, background work (WorkManager), and TLS.
