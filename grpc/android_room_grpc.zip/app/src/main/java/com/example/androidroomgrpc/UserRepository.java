package com.example.androidroomgrpc;

import android.content.Context;
import android.util.Log;

import com.example.androidroomgrpc.db.AppDatabase;
import com.example.androidroomgrpc.db.UserEntity;
import com.example.grpcdemo.Empty;
import com.example.grpcdemo.UserResponse;

import java.util.ArrayList;
import java.util.List;

public class UserRepository {
    private final AppDatabase db;
    private final GrpcClient grpc;

    public UserRepository(Context context) {
        db = AppDatabase.getInstance(context);
        grpc = new GrpcClient("10.0.2.2", 9090);
    }

    public List<UserEntity> getLocalUsers() {
        return db.userDao().getAll();
    }

    public void syncUsers() {
        new Thread(() -> {
            try {
                grpc.streamUpdates(0, new io.grpc.stub.StreamObserver<UserResponse>() {
                    List<UserEntity> list = new ArrayList<>();
                    @Override
                    public void onNext(UserResponse value) {
                        list.add(new UserEntity(value.getId(), value.getName(), value.getEmail(), value.getVersion()));
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("SYNC", "Error syncing users", t);
                    }

                    @Override
                    public void onCompleted() {
                        db.userDao().insertAll(list);
                        Log.d("SYNC", "Updated " + list.size() + " users");
                    }
                });
            } catch (Exception e) {
                Log.e("SYNC", "Error syncing users", e);
            }
        }).start();
    }
}
