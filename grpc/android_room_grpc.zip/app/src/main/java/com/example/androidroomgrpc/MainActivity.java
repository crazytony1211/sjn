package com.example.androidroomgrpc;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidroomgrpc.db.UserEntity;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private UserRepository repo;
    private EditText searchBox;
    private Button refreshBtn;
    private TextView status;

    // debounce
    private android.os.Handler handler = new android.os.Handler();
    private Runnable searchRunnable;

    // throttle
    private long lastCall = 0;
    private static final long THROTTLE_MS = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repo = new UserRepository(this);
        searchBox = findViewById(R.id.searchBox);
        refreshBtn = findViewById(R.id.refreshBtn);
        status = findViewById(R.id.status);

        // show cached
        new Thread(() -> {
            List<UserEntity> cached = repo.getLocalUsers();
            runOnUiThread(() -> status.setText("Local cached: " + cached.size() + " users"));
            Log.d("CACHE", "Loaded " + cached.size() + " local users");
        }).start();

        // debounce search -> sync
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (searchRunnable != null) handler.removeCallbacks(searchRunnable);
                searchRunnable = () -> {
                    repo.syncUsers();
                    runOnUiThread(() -> status.setText("Sync requested (debounced)"));
                };
                handler.postDelayed(searchRunnable, 500);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        refreshBtn.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastCall < THROTTLE_MS) return;
            lastCall = now;
            repo.syncUsers();
            status.setText("Sync requested (throttled)");
        });
    }
}
