package com.example.androidroomgrpc.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class UserEntity {
    @PrimaryKey
    @NonNull
    public String id;

    public String name;
    public String email;
    public long version;

    public UserEntity(@NonNull String id, String name, String email, long version) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.version = version;
    }
}
