package com.example.grpcclient;

import android.util.Log;
import com.example.grpcdemo.*;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import java.util.concurrent.TimeUnit;

public class GrpcClient {
    private final UserServiceGrpc.UserServiceBlockingStub blockingStub;
    private final UserServiceGrpc.UserServiceStub asyncStub;
    private final ManagedChannel channel;

    public GrpcClient(String host, int port) {
        channel = OkHttpChannelBuilder.forAddress(host, port)
                .usePlaintext()
                .keepAliveTime(60, TimeUnit.SECONDS)
                .keepAliveTimeout(20, TimeUnit.SECONDS)
                .maxInboundMessageSize(4 * 1024 * 1024)
                .build();

        blockingStub = UserServiceGrpc.newBlockingStub(channel).withCompression("gzip");
        asyncStub = UserServiceGrpc.newStub(channel).withCompression("gzip");
    }

    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }

    public void getUser(String id) {
        UserRequest req = UserRequest.newBuilder().setId(id).build();
        try {
            UserResponse res = blockingStub.getUser(req);
            Log.d("GRPC", "user: " + res.getName());
        } catch (Exception e) {
            Log.e("GRPC", "getUser error", e);
        }
    }

    public void streamUpdates(long sinceVersion) {
        UpdateRequest req = UpdateRequest.newBuilder().setSinceVersion(sinceVersion).build();
        asyncStub.getUserUpdates(req, new StreamObserver<UserResponse>() {
            @Override
            public void onNext(UserResponse value) {
                Log.d("GRPC", "update: " + value.getName());
            }

            @Override
            public void onError(Throwable t) {
                Log.e("GRPC", "stream error", t);
            }

            @Override
            public void onCompleted() {
                Log.d("GRPC", "stream completed");
            }
        });
    }
}
