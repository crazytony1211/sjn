package com.example.grpcclient;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private GrpcClient client;
    private EditText searchBox;
    private Button refreshBtn;

    // throttle state
    private long lastCall = 0;
    private static final long THROTTLE_MS = 1000; // 1s

    // debounce using Handler
    private android.os.Handler handler = new android.os.Handler();
    private Runnable searchRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        client = new GrpcClient("10.0.2.2", 9090);
        searchBox = findViewById(R.id.searchBox);
        refreshBtn = findViewById(R.id.refreshBtn);

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (searchRunnable != null) handler.removeCallbacks(searchRunnable);
                final String q = s.toString();
                searchRunnable = () -> {
                    client.streamUpdates(0);
                };
                handler.postDelayed(searchRunnable, 500); // 500ms debounce
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - lastCall < THROTTLE_MS) return; // throttle
                lastCall = now;
                client.streamUpdates(0);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { client.shutdown(); } catch (InterruptedException ignored) {}
    }
}
