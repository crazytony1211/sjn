package com.example.grpcdemo.config;

import com.example.grpcdemo.service.UserServiceImpl;
import io.grpc.Server;
import io.grpc.netty.NettyServerBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.io.IOException;

@Configuration
public class GrpcServerConfig {

    @Bean
    public Server grpcServer(UserServiceImpl userService) throws IOException {
        return NettyServerBuilder.forPort(9090)
                .addService(userService)
                .maxInboundMessageSize(4 * 1024 * 1024) // 4MB
                .build()
                .start();
    }
}
