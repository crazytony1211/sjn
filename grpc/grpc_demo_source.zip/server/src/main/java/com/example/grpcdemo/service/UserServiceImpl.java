package com.example.grpcdemo.service;

import com.example.grpcdemo.*;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import java.util.*;

@GrpcService
public class UserServiceImpl extends UserServiceGrpc.UserServiceImplBase {

    // In-memory store for demo; replace with JPA/DB in production
    private final List<UserRecord> store = Collections.synchronizedList(new ArrayList<>());
    public UserServiceImpl() {
        store.add(new UserRecord("1","Alice","alice@example.com",1));
        store.add(new UserRecord("2","Bob","bob@example.com",2));
        store.add(new UserRecord("3","Carol","carol@example.com",3));
    }

    @Override
    public void getUser(UserRequest request, StreamObserver<UserResponse> responseObserver) {
        store.stream()
            .filter(u -> u.id.equals(request.getId()))
            .findFirst()
            .ifPresent(u -> responseObserver.onNext(toProto(u)));
        responseObserver.onCompleted();
    }

    @Override
    public void streamUsers(Empty request, StreamObserver<UserResponse> responseObserver) {
        store.forEach(u -> responseObserver.onNext(toProto(u)));
        responseObserver.onCompleted();
    }

    @Override
    public void getUserUpdates(UpdateRequest request, StreamObserver<UserResponse> responseObserver) {
        long since = request.getSinceVersion();
        store.stream()
             .filter(u -> u.version > since)
             .forEach(u -> responseObserver.onNext(toProto(u)));
        responseObserver.onCompleted();
    }

    private UserResponse toProto(UserRecord u) {
        return UserResponse.newBuilder()
                .setId(u.id)
                .setName(u.name)
                .setEmail(u.email)
                .setVersion(u.version)
                .build();
    }

    // tiny record
    static class UserRecord { String id,name,email; long version; UserRecord(String id,String name,String email,long version){this.id=id;this.name=name;this.email=email;this.version=version;} }
}
