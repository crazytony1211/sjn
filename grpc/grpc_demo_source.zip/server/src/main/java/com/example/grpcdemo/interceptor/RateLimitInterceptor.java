package com.example.grpcdemo.interceptor;

import io.grpc.*;
import com.github.bucket4j.*;
import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;

public class RateLimitInterceptor implements ServerInterceptor {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    private Bucket bucketFor(String userId) {
        return buckets.computeIfAbsent(userId, k ->
            Bucket4j.builder()
                .addLimit(Bandwidth.simple(10, Duration.ofMinutes(1)))
                .build());
    }

    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call, Metadata headers, ServerCallHandler<ReqT, RespT> next) {

        Metadata.Key<String> key = Metadata.Key.of("user-id", Metadata.ASCII_STRING_MARSHALLER);
        String userId = headers.get(key);
        if (userId == null) userId = "anon";

        Bucket bucket = bucketFor(userId);
        if (!bucket.tryConsume(1)) {
            call.close(Status.RESOURCE_EXHAUSTED.withDescription("Too many requests"), new Metadata());
            return new ServerCall.Listener<ReqT>() {};
        }
        return next.startCall(call, headers);
    }
}
