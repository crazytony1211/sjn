# gRPC Demo (Android Client + Spring Boot Server)

This ZIP contains source-only runnable projects:

- `server/` — Spring Boot gRPC server (Maven)
- `android-client/` — Android app (Gradle)

How to run:

Server:
1. Open `server` in IntelliJ as a Maven project.
2. Run `mvn clean package` to compile protos and build.
3. Run `GrpcServerApplication` — server listens on gRPC port 9090.

Android:
1. Open `android-client` in Android Studio.
2. Build the project (Gradle will generate Java from proto).
3. Run on emulator; use host `10.0.2.2` to reach the server.

Notes:
- This is a minimal demo with in-memory data store.
- For production, add TLS/mTLS, persistent DB, authentication, and proper dependency versions.
